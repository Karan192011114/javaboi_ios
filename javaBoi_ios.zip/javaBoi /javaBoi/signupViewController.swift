//
//  signupViewController.swift
//  javaBoi
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class signupViewController: UIViewController {
    
    @IBOutlet weak var logo: UIImageView!
    
    @IBOutlet weak var background: UIImageView!
    
    @IBOutlet weak var username: UITextField!
    
    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    @IBOutlet weak var confirmpassword: UITextField!
    
    var details : Login!
    var userdetail : userdetails!
    
    let savedusername = UserDefaults.standard.value(forKey: "username")
    let savedpw = UserDefaults.standard.value(forKey: "pw")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.password.isSecureTextEntry = true
        self.confirmpassword.isSecureTextEntry = true
    }
    
    
    @IBAction func signupbtn(_ sender: Any) {
        loginDetailsAPI()
//        registerUser()
    }
    
    func registerUser() {
        let formData: [String: String] = [
            "username": username.text ?? "",
            "email": email.text ?? "",
            "password": password.text ?? "",
            "confirmpassword": confirmpassword.text ?? ""
        ]
        APIHandler().postAPIValues(type: Signup.self, apiUrl: ServiceAPI.signupUrl, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status)")
                print("Message: \(response.message)")
                DispatchQueue.main.async {
                    if self.username.text != self.userdetail.userData?.first?.username {
                        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "loginViewController") as! loginViewController
                        self.navigationController?.pushViewController(nextVC, animated: true)
                   } else {
                       AlertManager.showAlert(title: "Alert", message: "Username already exist", viewController: self)
                    }
                }
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }
    
    func loginDetailsAPI(){
        
        if password.text != confirmpassword.text{
            let alert = UIAlertController(title: "Password mismatch", message: "password and confirm password are not same", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        APIHandler().getAPIValues(type: userdetails.self, apiUrl: ServiceAPI.userdetailsUrl, method: "GET") { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status)")
                self.userdetail = response
                DispatchQueue.main.async {
                    if self.username.text == self.userdetail.userData?.first?.username || self.email.text == self.userdetail.userData?.first?.email{
                        let alert = UIAlertController(title: "Can't able to sign in", message: "Username and email already exits", preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }else{
                        self.registerUser()
                    }
                }
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }
}
