//
//  learnviewcontroller.swift
//  javaBoi
//
//  Created by SAIL on 05/10/23.
//

import UIKit
import WebKit

class learnviewcontroller: UIViewController {
    
    @IBOutlet weak var backbtn: UIImageView!
    @IBOutlet weak var homebtn: UIImageView!
    @IBOutlet weak var learnTableView: UITableView!
    
    var video: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        homebtn.addAction(for: .tap){
                    let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "competencyviewcontroller") as! competencyviewcontroller
                    self.navigationController?.pushViewController(signupVC, animated: true)
                }
        
        backbtn.addAction(for: .tap){
                self.navigationController?.popViewController(animated: true)
        }
        
        self.learnTableView.delegate = self
        self.learnTableView.dataSource = self
        
        // Do any additional setup after loading the view.
    }
    

    @IBAction func quizbtn(_ sender: Any) {
        let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewController") as! Quizviewcontroller
        self.navigationController?.pushViewController(signupVC, animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension learnviewcontroller: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "learnTableViewCell", for: indexPath) as! learnTableViewCell
        
        // YouTube Video ID
           let videoID = "BGTx91t8q50?si=-NbEIcrcHKLo_rct"
           
        if let url = URL(string: "https://www.youtube.com/embed/\(videoID)") {
                let requestObj = URLRequest(url: url)
                cell.webView.load(requestObj)
            }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 350
    }
}
