//
//  ScoreViewController.swift
//  javaBoi
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class ScoreViewController: UIViewController {

    @IBOutlet weak var homebtn: UIImageView!
    
    @IBOutlet weak var score: UILabel!
    
    @IBOutlet weak var scorebg: UIView!
    
    @IBOutlet weak var goback: UIButton!
    
    var Score: ScoreModel!
    var Score2: Score2Model!
    var Score3: Score3Model!
    var Score4: ScoreIntModel!
    var Score5: ScoreInt2Model!
    var Score6: ScoreInt3Model!
    var Score7: ScoreExpModel!
    var Score8: ScoreExp2Model!
    var Score9: ScoreExp3Model!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        homebtn.addAction(for: .tap){
                    let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "competencyviewcontroller") as! competencyviewcontroller
                    self.navigationController?.pushViewController(signupVC, animated: true)
                }
        
        // Do any additional setup after loading the view.
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if UserDefaultsManager.shared.getUserCompetency() == "Beginner" && UserDefaultsManager.shared.getUserLevel() == "1" {
        getProfileAPI()
    }
       else if UserDefaultsManager.shared.getUserCompetency() == "Beginner" && UserDefaultsManager.shared.getUserLevel() == "2" {
        getProfile2API()
    }
        else if UserDefaultsManager.shared.getUserCompetency() == "Beginner" && UserDefaultsManager.shared.getUserLevel() == "3" {
         getProfile3API()
    }
        else if UserDefaultsManager.shared.getUserCompetency() == "Intermediate" && UserDefaultsManager.shared.getUserLevel() == "1" {
         getProfile4API()
    }
        else if UserDefaultsManager.shared.getUserCompetency() == "Intermediate" && UserDefaultsManager.shared.getUserLevel() == "2" {
         getProfile5API()
    }
        else if UserDefaultsManager.shared.getUserCompetency() == "Intermediate" && UserDefaultsManager.shared.getUserLevel() == "3" {
         getProfile6API()
    }
        else if UserDefaultsManager.shared.getUserCompetency() == "Expert" && UserDefaultsManager.shared.getUserLevel() == "1" {
         getProfile7API()
    }
        else if UserDefaultsManager.shared.getUserCompetency() == "Expert" && UserDefaultsManager.shared.getUserLevel() == "2" {
         getProfile8API()
    }
        else if UserDefaultsManager.shared.getUserCompetency() == "Expert" && UserDefaultsManager.shared.getUserLevel() == "3" {
         getProfile9API()
    }

    func getProfileAPI() {
        APIHandler().getAPIValues(type: ScoreModel.self, apiUrl: ServiceAPI.level1pointsURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.Score = data
                print(self.Score.data ?? "")
                print(self.Score.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.score.text = "\(self.Score.data?.first?.points ?? 0)"
                    if self.Score.data?.first?.points ?? 0 > 5 {
                        self.scorebg.layer.borderWidth = 2.5
                        self.scorebg.layer.borderColor = UIColor.green.cgColor
                    } else {
                        self.scorebg.layer.borderWidth = 2.5
                        self.scorebg.layer.borderColor = UIColor.red.cgColor
                    }
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    func getProfile2API() {
        APIHandler().getAPIValues(type: Score2Model.self, apiUrl: ServiceAPI.level2pointsURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.Score2 = data
                print(self.Score2.data ?? "")
                print(self.Score2.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.score.text = self.Score2.data?.first?.quizScore
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    func getProfile3API() {
        APIHandler().getAPIValues(type: Score3Model.self, apiUrl: ServiceAPI.level3pointsURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.Score3 = data
                print(self.Score3.data ?? "")
                print(self.Score3.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.score.text = self.Score3.data?.first?.level3
                }
            case .failure(let error):
                print(error)
            }
        }
    }
        func getProfile4API() {
            APIHandler().getAPIValues(type: ScoreIntModel.self, apiUrl: ServiceAPI.Intlevel1pointsURL, method: "GET") { result in
                switch result {
                case .success(let data):
                    self.Score4 = data
                    print(self.Score4.data ?? "")
                    print(self.Score4.data?.count ?? 0)
                    DispatchQueue.main.async {
                        self.score.text = self.Score4.data?.first?.intLevel1
                    }
                case .failure(let error):
                    print(error)
                }
            }
        }
        func getProfile5API() {
            APIHandler().getAPIValues(type: ScoreInt2Model.self, apiUrl: ServiceAPI.Intlevel2pointsURL, method: "GET") { result in
                switch result {
                case .success(let data):
                    self.Score5 = data
                    print(self.Score5.data ?? "")
                    print(self.Score5.data?.count ?? 0)
                    DispatchQueue.main.async {
                        self.score.text = self.Score5.data?.first?.intLevel2
                    }
                case .failure(let error):
                    print(error)
                }
            }
        }
        func getProfile6API() {
            APIHandler().getAPIValues(type: ScoreInt3Model.self, apiUrl: ServiceAPI.Intlevel3pointsURL, method: "GET") { result in
                switch result {
                case .success(let data):
                    self.Score6 = data
                    print(self.Score6.data ?? "")
                    print(self.Score6.data?.count ?? 0)
                    DispatchQueue.main.async {
                        self.score.text = self.Score6.data?.first?.intLevel3
                    }
                case .failure(let error):
                    print(error)
                }
            }
        }
        func getProfile7API() {
            APIHandler().getAPIValues(type: ScoreExpModel.self, apiUrl: ServiceAPI.Explevel1pointsURL, method: "GET") { result in
                switch result {
                case .success(let data):
                    self.Score7 = data
                    print(self.Score7.data ?? "")
                    print(self.Score7.data?.count ?? 0)
                    DispatchQueue.main.async {
                        self.score.text = self.Score7.data?.first?.expLevel1
                    }
                case .failure(let error):
                    print(error)
                }
            }
        }
        func getProfile8API() {
            APIHandler().getAPIValues(type: ScoreExp2Model.self, apiUrl: ServiceAPI.Explevel2pointsURL, method: "GET") { result in
                switch result {
                case .success(let data):
                    self.Score8 = data
                    print(self.Score8.data ?? "")
                    print(self.Score8.data?.count ?? 0)
                    DispatchQueue.main.async {
                        self.score.text = self.Score8.data?.first?.expLevel2
                    }
                case .failure(let error):
                    print(error)
                }
            }
        }
        func getProfile9API() {
            APIHandler().getAPIValues(type: ScoreExp3Model.self, apiUrl: ServiceAPI.Explevel3pointsURL, method: "GET") { result in
                switch result {
                case .success(let data):
                    self.Score9 = data
                    print(self.Score9.data ?? "")
                    print(self.Score9.data?.count ?? 0)
                    DispatchQueue.main.async {
                        self.score.text = self.Score9.data?.first?.expLevel3
                    }
                case .failure(let error):
                    print(error)
                }
            }
        }
    }

    
    @IBAction func goback(_ sender: Any) {
        for controller in self.navigationController!.viewControllers as Array {
            if controller.isKind(of: levelViewController.self) {
                self.navigationController!.popToViewController(controller, animated: true)
                break
            }
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
