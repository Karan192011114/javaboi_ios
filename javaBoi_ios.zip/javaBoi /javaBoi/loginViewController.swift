//
//  loginViewController.swift
//  javaBoi
//
//  Created by SAIL on 20/09/23.
//

import UIKit

class loginViewController: UIViewController {
    
    @IBOutlet weak var signup: UIButton!
    @IBOutlet weak var signuptext: UILabel!
    @IBOutlet weak var login: UIButton!
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var logo: UIImageView!
    @IBOutlet weak var background: UIImageView!
    
    var apiURL = String()
    var loginModel: Login!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func loginbtn(_ sender: Any) {
        
        apiURL = "http://192.168.244.229/javaboi1/login.php?username=\(username.text  ?? "")&password=\(password.text ?? "")"
        
        if username.text == "" && password.text == "" {
            let alert = UIAlertController(title: "Alert", message: "Textfield is Empty", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            present(alert, animated: true)
        } else {
            getLoginAPI()
        }
    }
    
    
    @IBAction func signupbtn(_ sender: Any) {
        let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "signupViewController") as! signupViewController
        self.navigationController?.pushViewController(signupVC, animated: true)
    }
    
    func getLoginAPI() {
        APIHandler().getAPIValues(type: Login.self, apiUrl: apiURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.loginModel = data
                print(self.loginModel.data ?? "")
                DispatchQueue.main.async {
                    if self.username.text != self.loginModel.data?.first?.username && self.password.text != self.loginModel.data?.first?.password {
                        let alert = UIAlertController(title: "Alert", message: "Incorrect ID or Password", preferredStyle: UIAlertController.Style.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                        self.present(alert, animated: true)
                    } else {
//                        self.Logins()
                        UserDefaults.standard.setValue(self.loginModel.data?.first?.username, forKey: "username")
                        UserDefaults.standard.setValue(self.loginModel.data?.first?.password, forKey: "pw")
                        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
                        let vc = storyboard.instantiateViewController(withIdentifier: "competencyviewcontroller") as! competencyviewcontroller
                        self.navigationController?.pushViewController(vc, animated: true)
                    }
                }
            case .failure(let error):
                print(error)
            }
        }
    }
//    func Logins() {
//            let formData: [String: String] = [
//                "username": username.text ?? "",
//                "password": password.text ?? "",
//            ]
//        APIHandler().postAPIValues(type: Loginsession.self, apiUrl: ServiceAPI.loginsessionURL, method: "POST", formData: formData) { result in
//                switch result {
//                case .success(let response):
//                    print("Message: \(response.message)")
//                    DispatchQueue.main.async {
//                      let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "competencyviewcontroller") as! competencyviewcontroller
//                        self.navigationController?.pushViewController(nextVC, animated: true)
//                    }
//                case .failure(let error):
//                    print("Error: \(error)")
//                }
//            }
//        }
}
    
