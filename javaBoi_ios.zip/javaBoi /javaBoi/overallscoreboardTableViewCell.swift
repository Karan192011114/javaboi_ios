////
////  overallscoreboardTableViewCell.swift
////  javaBoi
////
////  Created by SAIL on 14/10/23.
////
//
//import UIKit
//
//class overallscoreboardTableViewCell: UITableViewCell {
//
//    @IBOutlet weak var feather: UIImageView!
//    
//    @IBOutlet weak var points: UILabel!
//    
//    @IBOutlet weak var username: UILabel!
//    
//    override func awakeFromNib() {
//        super.awakeFromNib()
//        homebtn.addAction(for: .tap){
//            let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "levelViewController") as! levelViewController
//            self.navigationController?.pushViewController(signupVC, animated: true)
//        }
//        // Initialization code
//    }
//
//    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//
//        // Configure the view for the selected state
//    }
//
//}
