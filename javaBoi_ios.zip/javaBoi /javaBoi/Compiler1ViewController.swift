//
//  Compiler1ViewController.swift
//  javaBoi
//
//  Created by SAIL on 18/11/23.
//
//
//import UIKit
//
//class Compiler1ViewController: UIViewController {
//
//    @IBOutlet weak var usernameTextField: UITextField!
//    
//    
//    @IBOutlet weak var codeTextView: UITextView!
//    
//  
//    @IBOutlet weak var inputTextView: UITextView!
//    
//    var compilerdetail : Compiler!
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        // Do any additional setup after loading the view.
//    }
//    
//    let apiHandler = APIHandler()
//
//        @IBAction func makeAPIRequest(_ sender: UIButton) {
//            guard let username = usernameTextField.text, !username.isEmpty else {
//                showAlert(message: "Please enter a username")
//                return
//            }
//            guard let code = codeTextView.text else {
//                // Handle the case where codeTextView.text is nil
//                return
//            }
//
//            let lines = code.components(separatedBy: .newlines)
//            let trimmedLines = lines.map { $0.trimmingCharacters(in: .whitespaces) }
//            var formattedCode = trimmedLines.joined(separator: " ")
//
//            // Remove \ before quotation marks inside brackets
//            formattedCode = formattedCode.replacingOccurrences(of: "\"", with: " ")
//
////            guard let code = codeTextView.text?.trimmingCharacters(in: .whitespacesAndNewlines), !code.isEmpty else {
////                showAlert(message: "Please enter code")
////                return
////            }
//
//            guard let input = inputTextView.text else {
//                showAlert(message: "Please enter input data")
//                return
//            }
//            
//          
//            APIHandler.shared.postAPIValuesCompiler(type: Compiler.self, apiURL: ServiceAPI.CompilerURL, method: "POST", username: username, code: formattedCode, input: input) { result in
//                DispatchQueue.main.async {
//                    switch result {
//                        case .success(let compilerResponse):
//                            do {
//                                let encoder = JSONEncoder()
//                                encoder.outputFormatting = .prettyPrinted
//                                let jsonData = try encoder.encode(compilerResponse)
//                                
//                                // Now print the raw JSON response
//                                if let jsonString = String(data: jsonData, encoding: .utf8) {
//                                    print("Raw JSON Response:" ,jsonString)
//                                }
//
//                                // Access the properties of the compilerModel as needed
////                                print("Username: \(compilerResponse.username ?? "")")
////                                print("Code: \(compilerResponse.code ?? "")")
////                                print("InputData: \(compilerResponse.inputData ?? "")")
////                                print("Output: \(compilerResponse.output ?? "")")
////                                print("output: \(compilerResponse.categorizedOutput)")
//                            } catch {
//                                print("Error encoding JSON: \(error)")
//                            }
//                            
//                        case .failure(let error):
//                            self.showAlert(message: "Error: \(error.localizedDescription)")
//                        }
////                    case .success(let compilerdetail):
////
////                        // Access the properties of the compilerModel as needed
////                        print("Raw JSON Response: \(compilerdetail)")
////                        print("Username: \(compilerdetail.username ?? "")")
////                        print("Code: \(compilerdetail.code ?? "")")
////                        print("InputData: \(compilerdetail.inputData ?? "")")
////                        print("Output: \(compilerdetail.output ?? "")")
////
////                        self.compilerdetail = compilerdetail // assuming compilerdetail is of type Compiler
////                    case .failure(let error):
////                        self.showAlert(message: "Error: \(error.localizedDescription)")
////                    }
//                }
//            }
//                }
//
//                func showAlert(message: String) {
//                    DispatchQueue.main.async {
//                        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
//                        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
//                        self.present(alert, animated: true, completion: nil)
//                    }
//                }
//            }
//    /*
//    // MARK: - Navigation
//
//    // In a storyboard-based application, you will often want to do a little preparation before navigation
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        // Get the new view controller using segue.destination.
//        // Pass the selected object to the new view controller.
//    }
//    */
//
