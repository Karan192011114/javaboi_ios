//
//  UserDefault.swift
//  javaBoi
//
//  Created by SAIL on 18/10/23.
//
import Foundation

class UserDefaultsManager {
    static let shared = UserDefaultsManager()

    private let userDefaults = UserDefaults.standard

    private init() {}

    // MARK: - Define Keys for Your Data
    private let userCompentencyKey = "UserCompentency"
    
    private let userLevelKey = "UserLevel"

    // MARK: - Save Data
    func saveUserCompetency(_ name: String) {
        userDefaults.set(name, forKey: userCompentencyKey)
    }

    func saveUserLevel(_ level: String) {
        userDefaults.set(level, forKey: userLevelKey)
    }

    // MARK: - Retrieve Data
    func getUserCompetency() -> String? {
        return userDefaults.string(forKey: userCompentencyKey)
    }

    func getUserLevel() -> String? {
        return userDefaults.string(forKey: userLevelKey)
    }

    // MARK: - Remove Data (if needed)
    func removeUserData() {
        userDefaults.removeObject(forKey: userCompentencyKey)
        userDefaults.removeObject(forKey: userLevelKey)
    }
}

