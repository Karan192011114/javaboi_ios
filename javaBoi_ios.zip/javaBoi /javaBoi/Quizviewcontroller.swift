//
//  Quizviewcontroller.swift
//  javaBoi
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class Quizviewcontroller: UIViewController {
    var SubmitScoreModel: SubmitScore!
    var ResponseData : JsonResponseModel!
    var score = 0 // to count the correct answer
    
    @IBOutlet weak var homebtn: UIImageView!
    @IBOutlet weak var backbtn: UIImageView!
    @IBOutlet weak var tableView: UITableView! {
        didSet {
            tableView.delegate = self
            tableView.dataSource = self
        }
    }
    
    var currentQuestionIndex = 0
    var selectedAnswerIndex: Int?
    var isCurrentQuestionAnswered = false


    override func viewDidLoad() {
        super.viewDidLoad()
        
        homebtn.addAction(for: .tap){
                    let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "competencyviewcontroller") as! competencyviewcontroller
                    self.navigationController?.pushViewController(signupVC, animated: true)
                }
        
        backbtn.addAction(for: .tap){
                self.navigationController?.popViewController(animated: true)
        }
        
        
        if UserDefaultsManager.shared.getUserCompetency() == "Beginner" && UserDefaultsManager.shared.getUserLevel() == "1" {
            loadjson()
        } else if UserDefaultsManager.shared.getUserCompetency() == "Beginner"  && UserDefaultsManager.shared.getUserLevel() == "2" {
            load1json()
    } else if UserDefaultsManager.shared.getUserCompetency() == "Beginner" && UserDefaultsManager.shared.getUserLevel() == "3" {
            load2json()
        }
        if UserDefaultsManager.shared.getUserCompetency() == "Intermediate" && UserDefaultsManager.shared.getUserLevel() == "1" {
            loadintjson()
        } else if UserDefaultsManager.shared.getUserCompetency() == "Intermediate"  && UserDefaultsManager.shared.getUserLevel() == "2" {
            loadint2json()
    } else if UserDefaultsManager.shared.getUserCompetency() == "Intermediate" && UserDefaultsManager.shared.getUserLevel() == "3" {
            loadint3json()
        }
        if UserDefaultsManager.shared.getUserCompetency() == "Expert" && UserDefaultsManager.shared.getUserLevel() == "1" {
            loadexpjson()
        } else if UserDefaultsManager.shared.getUserCompetency() == "Expert"  && UserDefaultsManager.shared.getUserLevel() == "2" {
            loadexp2json()
    } else if UserDefaultsManager.shared.getUserCompetency() == "Expert" && UserDefaultsManager.shared.getUserLevel() == "3" {
        loadexp3json()
        }
    }
    
    func loadjson() {
        APIHandler().getAPIValues(type: JsonResponseModel.self, apiUrl: ServiceAPI.quizl1URL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.ResponseData = data
                print(self.ResponseData.questions ?? "")
                print(self.ResponseData.questions?.count ?? 0)
                DispatchQueue.main.async {
                    UserDefaults.standard.setValue(self.ResponseData.questions?.first?.correct, forKey: "CorrectValue")
                    self.tableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
    func load1json() {
        APIHandler().getAPIValues(type: JsonResponseModel.self, apiUrl: ServiceAPI.quizl2URL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.ResponseData = data
                print(self.ResponseData.questions ?? "")
                print(self.ResponseData.questions?.count ?? 0)
                DispatchQueue.main.async {
                    UserDefaults.standard.setValue(self.ResponseData.questions?.first?.correct, forKey: "CorrectValue")
                    self.tableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
    func load2json() {
        APIHandler().getAPIValues(type: JsonResponseModel.self, apiUrl: ServiceAPI.quizl3URL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.ResponseData = data
                print(self.ResponseData.questions ?? "")
                print(self.ResponseData.questions?.count ?? 0)
                DispatchQueue.main.async {
                    UserDefaults.standard.setValue(self.ResponseData.questions?.first?.correct, forKey: "CorrectValue")
                    self.tableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    func loadintjson() {
        APIHandler().getAPIValues(type: JsonResponseModel.self, apiUrl: ServiceAPI.quizl1intURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.ResponseData = data
                print(self.ResponseData.questions ?? "")
                print(self.ResponseData.questions?.count ?? 0)
                DispatchQueue.main.async {
                    UserDefaults.standard.setValue(self.ResponseData.questions?.first?.correct, forKey: "CorrectValue")
                    self.tableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    func loadint2json() {
        APIHandler().getAPIValues(type: JsonResponseModel.self, apiUrl: ServiceAPI.quizl2intURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.ResponseData = data
                print(self.ResponseData.questions ?? "")
                print(self.ResponseData.questions?.count ?? 0)
                DispatchQueue.main.async {
                    UserDefaults.standard.setValue(self.ResponseData.questions?.first?.correct, forKey: "CorrectValue")
                    self.tableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    func loadint3json() {
        APIHandler().getAPIValues(type: JsonResponseModel.self, apiUrl: ServiceAPI.quizl3intURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.ResponseData = data
                print(self.ResponseData.questions ?? "")
                print(self.ResponseData.questions?.count ?? 0)
                DispatchQueue.main.async {
                    UserDefaults.standard.setValue(self.ResponseData.questions?.first?.correct, forKey: "CorrectValue")
                    self.tableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    func loadexpjson() {
        APIHandler().getAPIValues(type: JsonResponseModel.self, apiUrl: ServiceAPI.quizl1expURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.ResponseData = data
                print(self.ResponseData.questions ?? "")
                print(self.ResponseData.questions?.count ?? 0)
                DispatchQueue.main.async {
                    UserDefaults.standard.setValue(self.ResponseData.questions?.first?.correct, forKey: "CorrectValue")
                    self.tableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    func loadexp2json() {
        APIHandler().getAPIValues(type: JsonResponseModel.self, apiUrl: ServiceAPI.quizl2expURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.ResponseData = data
                print(self.ResponseData.questions ?? "")
                print(self.ResponseData.questions?.count ?? 0)
                DispatchQueue.main.async {
                    UserDefaults.standard.setValue(self.ResponseData.questions?.first?.correct, forKey: "CorrectValue")
                    self.tableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    func loadexp3json() {
        APIHandler().getAPIValues(type: JsonResponseModel.self, apiUrl: ServiceAPI.quizl3expURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.ResponseData = data
                print(self.ResponseData.questions ?? "")
                print(self.ResponseData.questions?.count ?? 0)
                DispatchQueue.main.async {
                    
                    self.tableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }

//    func loadJson(filename fileName: String) -> [Question]? {
//        if let url = Bundle.main.url(forResource: fileName, withExtension: "json") {
//            do {
//                let data = try Data(contentsOf: url)
//                let decoder = JSONDecoder()
//                let jsonData = try decoder.decode(JsonResponseModel.self, from: data)
//                ResponseData = jsonData
//                print(jsonData,"--->")
//                DispatchQueue.main.async {
//                    self.tableView.reloadData()
//                }
//                return jsonData.questions
//
//            } catch {
//                print("error:\(error)")
//            }
//        }
//        return nil
//    }
}

extension Quizviewcontroller: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ResponseData?.questions?.count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "QnsTabCell", for: indexPath) as! QnsTabCell
        
        if let question = ResponseData.questions?[currentQuestionIndex] {
            cell.qns.text = question.question

            for (index, button) in cell.optionButtons.enumerated() {
                if index < question.answer?.count ?? 0 {
                    button.setTitle(question.answer?[index].text, for: .normal)
                    button.tag = index
                    button.addTarget(self, action: #selector(answerButtonTapped(_:)), for: .touchUpInside)
                    button.isUserInteractionEnabled = true // Re-enable the button

                    if let selectedAnswerIndex = selectedAnswerIndex {
                        // Disable buttons other than the selected answer
                        if index != selectedAnswerIndex {
                            button.isUserInteractionEnabled = false
                        }
                    }

                    // Reset the button background color to clear
                    button.backgroundColor = .clear
                    button.isEnabled = true
                } else {
                    button.setTitle(nil, for: .normal)
                }
            }
        } else {
            cell.qns.text = ""
            for button in cell.optionButtons {
                button.setTitle(nil, for: .normal)
                button.isEnabled = false
            }
        }

        return cell
    }

//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "QnsTabCell") as! QnsTabCell
//        if let quns = ResponseData.questions, indexPath.row < quns.count {
//            cell.qns.text = quns[indexPath.row].question
//
//        }
//        if let ans = ResponseData.answer, indexPath.row < ans.count {
//            cell.optionButtons.text = ans[indexPath.row].text
//
//        }
//        if let question = ResponseData.questions?[currentQuestionIndex] {
//            cell.qns.text = question.question
//
//            for (index, button) in cell.optionButtons.enumerated() {
//                if index < question.answer?.count ?? 0 {
//                    button.setTitle(question.answer?[index].text, for: .normal)
//                    button.tag = index
//                    button.addTarget(self, action: #selector(answerButtonTapped(_:)), for: .touchUpInside)
//                    button.isUserInteractionEnabled = true // Re-enable the button
//
//                    if let selectedAnswerIndex = selectedAnswerIndex {
//                        // Disable buttons other than the selected answer
//                        if index != selectedAnswerIndex {
//                            button.isUserInteractionEnabled = false
//                        }
//                    }
//
//                    // Reset the button background color to clear
//                    button.backgroundColor = .clear
//                    button.isEnabled = true
//                } else {
//                    button.setTitle(nil, for: .normal)
//                }
//            }
//        }
//
//        return cell
//    }


    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return view.bounds.height
    }
    
    func sendCorrectAnswerCountToServer() {
        
        let formData = [
            "points": score
        ]
        
        APIHandler().postAPIValuesScore(type: SubmitScore.self, apiUrl: ServiceAPI.submitScoreURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                self.SubmitScoreModel = data
                print(self.SubmitScoreModel.score ?? "")
            case .failure(let error):
                print(error)
        }
    }
    }
        
    
    func sendCorrectAnswerCountToServer2() {
      
        let formData = [
            "points": score
        ]
        
        APIHandler().postAPIValuesScore(type: SubmitScore.self, apiUrl: ServiceAPI.submitScore2URL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                self.SubmitScoreModel = data
                print(self.SubmitScoreModel.score ?? "")
            case .failure(let error):
                print(error)
        }
    }
    }
        
    func sendCorrectAnswerCountToServer3() {
      
        let formData = [
            "points": score
        ]
        
        APIHandler().postAPIValuesScore(type: SubmitScore.self, apiUrl: ServiceAPI.submitScore3URL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                self.SubmitScoreModel = data
                print(self.SubmitScoreModel.score ?? "")
            case .failure(let error):
                print(error)
        }
    }
    }
    func sendCorrectAnswerCountToServerint() {
      
        let formData = [
            "points": score
        ]
        
        APIHandler().postAPIValuesScore(type: SubmitScore.self, apiUrl: ServiceAPI.submitScoreIntURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                self.SubmitScoreModel = data
                print(self.SubmitScoreModel.score ?? "")
            case .failure(let error):
                print(error)
        }
    }
    }
    
    func sendCorrectAnswerCountToServerint2() {
      
        let formData = [
            "points": score
        ]
        
        APIHandler().postAPIValuesScore(type: SubmitScore.self, apiUrl: ServiceAPI.submitScoreInt2URL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                self.SubmitScoreModel = data
                print(self.SubmitScoreModel.score ?? "")
            case .failure(let error):
                print(error)
        }
    }
    }
    
    func sendCorrectAnswerCountToServerint3() {
      
        let formData = [
            "points": score
        ]
        
        APIHandler().postAPIValuesScore(type: SubmitScore.self, apiUrl: ServiceAPI.submitScoreInt3URL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                self.SubmitScoreModel = data
                print(self.SubmitScoreModel.score ?? "")
            case .failure(let error):
                print(error)
        }
    }
    }
    func sendCorrectAnswerCountToServerexp() {
      
        let formData = [
            "points": score
        ]
        
        APIHandler().postAPIValuesScore(type: SubmitScore.self, apiUrl: ServiceAPI.submitScoreExpURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                self.SubmitScoreModel = data
                print(self.SubmitScoreModel.score ?? "")
            case .failure(let error):
                print(error)
        }
    }
    }
    func sendCorrectAnswerCountToServerexp2() {
      
        let formData = [
            "points": score
        ]
        
        APIHandler().postAPIValuesScore(type: SubmitScore.self, apiUrl: ServiceAPI.submitScoreExp2URL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                self.SubmitScoreModel = data
                print(self.SubmitScoreModel.score ?? "")
            case .failure(let error):
                print(error)
        }
    }
    }
    func sendCorrectAnswerCountToServerexp3() {
      
        let formData = [
            "points": score
        ]
        
        APIHandler().postAPIValuesScore(type: SubmitScore.self, apiUrl: ServiceAPI.submitScoreExp3URL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                self.SubmitScoreModel = data
                print(self.SubmitScoreModel.score ?? "")
            case .failure(let error):
                print(error)
        }
    }
    }
    
    @objc func answerButtonTapped(_ sender: UIButton) {
        if let question = ResponseData.questions?[currentQuestionIndex] {
            let selectedAnswer = question.answer?[sender.tag]

            if selectedAnswer?.correct ?? true {
//                Increment the correctAnswerCount
                
                score += question.value ?? 0
                UserDefaults.standard.set("Correct", forKey: "AnswerStatus")
                // Provide feedback for a correct answer
                sender.backgroundColor = .green
            } else {
                UserDefaults.standard.set("Wrong", forKey: "AnswerStatus")
                UserDefaults.standard.setValue(self.ResponseData.questions?.first?.correct, forKey: "CorrectValue")
                // Provide feedback for an incorrect answer
                sender.backgroundColor = .red
            }
            if UserDefaultsManager.shared.getUserCompetency() == "Beginner" && UserDefaultsManager.shared.getUserLevel() == "1" {
            sendCorrectAnswerCountToServer()
            }
            if UserDefaultsManager.shared.getUserCompetency() == "Beginner" && UserDefaultsManager.shared.getUserLevel() == "2" {
            sendCorrectAnswerCountToServer2()
            }
            if UserDefaultsManager.shared.getUserCompetency() == "Beginner" && UserDefaultsManager.shared.getUserLevel() == "3" {
            sendCorrectAnswerCountToServer3()
            }
            if UserDefaultsManager.shared.getUserCompetency() == "Intermediate" && UserDefaultsManager.shared.getUserLevel() == "1" {
            sendCorrectAnswerCountToServerint()
            }
            if UserDefaultsManager.shared.getUserCompetency() == "Intermediate" && UserDefaultsManager.shared.getUserLevel() == "2" {
            sendCorrectAnswerCountToServerint2()
            }
            if UserDefaultsManager.shared.getUserCompetency() == "Intermediate" && UserDefaultsManager.shared.getUserLevel() == "3" {
            sendCorrectAnswerCountToServerint3()
            }
            if UserDefaultsManager.shared.getUserCompetency() == "Expert" && UserDefaultsManager.shared.getUserLevel() == "1" {
            sendCorrectAnswerCountToServerexp()
            }
            if UserDefaultsManager.shared.getUserCompetency() == "Expert" && UserDefaultsManager.shared.getUserLevel() == "2" {
            sendCorrectAnswerCountToServerexp2()
            }
            if UserDefaultsManager.shared.getUserCompetency() == "Expert" && UserDefaultsManager.shared.getUserLevel() == "3" {
            sendCorrectAnswerCountToServerexp3()
            }
            
//            nextButton.isHidden = false
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    let viewController = storyboard.instantiateViewController(withIdentifier: "AnswerViewController") as! AnswerViewController
            viewController.delegate = self
            viewController.providesPresentationContextTransitionStyle = true
            viewController.definesPresentationContext = true
            viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
            self.present(viewController, animated: true)
            viewController.view.backgroundColor = UIColor.clear
        }
    }

}


extension Quizviewcontroller: NextButtonDelegate {
    func nextButtonTapped() {
        currentQuestionIndex += 1

        if currentQuestionIndex < (ResponseData.questions?.count ?? 0) {
            UserDefaults.standard.setValue("", forKey: "CorrectValue")
            tableView.reloadData()
        } else {
            let VC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ScoreViewController") as! ScoreViewController
            self.navigationController?.pushViewController(VC, animated: true)
        }
            // Handle the end of the quiz logic, e.g., display a message or navigate to a different screen.
        }
    }


class QnsTabCell : UITableViewCell {
    @IBOutlet weak var qns: UILabel!
    @IBOutlet var optionButtons: [UIButton]!

}
