//
//  ViewController.swift
//  javaBoi
//
//  Created by SAIL on 19/09/23.
//



import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var login: UIView!
    
   
}

