//
//  Achievementviewcontroller.swift
//  javaBoi
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class Achievementviewcontroller: UIViewController {

    @IBOutlet weak var backbtn: UIImageView!
    
    @IBOutlet weak var homebtn: UIImageView!
    
    @IBOutlet weak var beginner_badgeimg: UIImageView!
    
    
    @IBOutlet weak var intermediate_badgeimg: UIImageView!
    
    
    @IBOutlet weak var expert_badgeimg: UIImageView!
    
    
    @IBOutlet weak var achievementlable: UILabel!
    

    @IBOutlet weak var beginner_badge: UIView!
    
    @IBOutlet weak var intermediate_badge: UIView!
    
    
    @IBOutlet weak var expert_badge: UIView!
    
    // Sample data, replace with your actual data
    var AchievementModel: Achievement!

       override func viewDidLoad() {
           super.viewDidLoad()
           
           homebtn.addAction(for: .tap){
                       let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "competencyviewcontroller") as! competencyviewcontroller
                       self.navigationController?.pushViewController(signupVC, animated: true)
                   }
           
           backbtn.addAction(for: .tap){
                   self.navigationController?.popViewController(animated: true)
           }
       }
       
       override func viewWillAppear(_ animated: Bool) {
           
           getProfileAPI()
       }
       
       func getProfileAPI() {
           APIHandler().getAPIValues(type: Achievement.self, apiUrl: ServiceAPI.achievementURL, method: "GET", onCompletion: { result in
               switch result {
               case .success(let data):
                   self.AchievementModel = data
                   DispatchQueue.main.async {
                       if let beginnerScore = self.AchievementModel.data?.first?.beginnerScore,
                          let intermediateScore = self.AchievementModel.data?.first?.intermediateScore,
                          let expertScore = self.AchievementModel.data?.first?.expertScore {
                           if beginnerScore > 10 {
                               
                           } else {
                               self.applyBlurEffect(to: self.beginner_badge)
                           }

                           if intermediateScore > 10 {
//
                           } else {
                               self.applyBlurEffect(to: self.intermediate_badge)
                           }

                           if expertScore > 10 {
                               
                           } else {
                               self.applyBlurEffect(to: self.expert_badge)
                           }
                       } else {
                           print("Invalid score data received from the API")
                       }
                   }
               case .failure(let error):
                   print(error)
                   // Handle API request failure, show an error message to the user, or take other actions
               }
           })
       }

       func applyBlurEffect(to container: UIView) {
           let blurEffect = UIBlurEffect(style: .dark)
           let visualEffectView = UIVisualEffectView(effect: blurEffect)
           visualEffectView.frame = container.bounds
           visualEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
           container.addSubview(visualEffectView)
       }
   }
