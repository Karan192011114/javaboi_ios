//
//  CorrectViewController.swift
//  JsonResponse
//
//  Created by Haris Madhavan on 23/10/23.
//

import UIKit

protocol NextButtonDelegate: AnyObject {
    func nextButtonTapped()
}

class AnswerViewController: UIViewController {
    
    var ResponseData: JsonResponseModel!
    weak var delegate: NextButtonDelegate?
    @IBOutlet weak var answerView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var answerLabel: UILabel!
    @IBOutlet weak var nextButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if let answerStatus = UserDefaults.standard.string(forKey: "AnswerStatus") {
            DispatchQueue.main.async { [self] in
                if answerStatus == "Correct" {
                    self.titleLabel.text = "Correct Answer"
                } else if answerStatus == "Wrong" {
                    self.titleLabel.text = "Wrong Answer"
                    let answerValue : String = UserDefaults.standard.value(forKey: "CorrectValue") as! String
                    self.answerLabel.text = "Correct Answer: \(answerValue)"
                    self.answerView.backgroundColor = UIColor(red: 255/255.0, green: 165/255.0, blue: 186/255.0, alpha: 1)
                    self.nextButton.backgroundColor = UIColor(red: 230/255.0, green: 41/255.0, blue: 73/255.0, alpha: 1)
                }
            }
        }
            
            // Clear the stored answer status
            UserDefaults.standard.removeObject(forKey: "AnswerStatus")
    }
    
    @IBAction func buttonAction(_ sender: Any) {
        delegate?.nextButtonTapped()
        self.dismiss(animated: true)
    }
    
    
}
