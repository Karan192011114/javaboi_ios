//
//  scoreboardTableViewCell.swift
//  javaBoi
//
//  Created by SAIL L1 on 11/10/23.
//

import UIKit

class scoreboardTableViewCell: UITableViewCell {

    @IBOutlet weak var username: UILabel!
    
    @IBOutlet weak var points: UILabel!
    
    @IBOutlet weak var feather: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
