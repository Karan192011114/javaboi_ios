//
//  CompilerViewController.swift
//  javaBoi
//
//  Created by SAIL on 02/11/23.
//

import UIKit
import WebKit

class CompilerViewController: UIViewController {

    @IBOutlet weak var webView: WKWebView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        if let url = URL (string:"http://192.168.244.229/javaboi1/compiler1.html"){
            let requestObj = URLRequest(url: url)
            self.webView.load(requestObj)
            self.webView.scrollView.maximumZoomScale = 1.0
            self.webView.scrollView.minimumZoomScale = 1.0
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
