//
//  APIHandler.swift
//  WeatherApp
//
//  Created by MAC-Air on 08/09/23.
//

import Foundation
import UIKit


class APIHandler {
    static var shared: APIHandler = APIHandler()
    
    init() {}
    
    func getAPIValues<T:Codable>(type: T.Type, apiUrl: String, method: String, onCompletion: @escaping (Result<T, Error>) -> Void) {
        
        let startTime = Date() // Start time before making the API call
                
        guard let url = URL(string: apiUrl) else {
                    let error = NSError(domain: "Invalid URL", code: 0, userInfo: nil)
                    onCompletion(.failure(error))
                    return
                }
        print("API call started at: \(startTime)")
                
                var request = URLRequest(url: url)
                request.httpMethod = "GET"
                                
                let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
                    
                    let endTime = Date() // End time after receiving the API response
                    
                    
                    let responseTime = endTime.timeIntervalSince(startTime) // Calculate the duration in seconds
                    
                    
                    
                    if let error = error {
                        onCompletion(.failure(error))
                        return
                    }
                    
                    guard let data = data else {
                        let error = NSError(domain: "No data received", code: 1, userInfo: nil)
                        onCompletion(.failure(error))
                        return
                    }
                    
                    do {
                        let decodedData = try JSONDecoder().decode(type, from: data)
                        onCompletion(.success(decodedData))
                        print(decodedData)
                        print("API call ended at: \(endTime)")
                        print("API response time: \(responseTime) seconds")
                    } catch {
                        onCompletion(.failure(error))
                    }
                }
                
                task.resume()
            }
    
    func postAPIValues<T: Codable>(
        type: T.Type,
        apiUrl: String,
        method: String,
        formData: [String: String], // Dictionary for form data parameters
        onCompletion: @escaping (Result<T, Error>) -> Void
    ) {
        let startTime = Date() // Start time before making the API call
        
        guard let url = URL(string: apiUrl) else {
            let error = NSError(domain: "Invalid URL", code: 0, userInfo: nil)
            onCompletion(.failure(error))
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        // Construct the form data string
        var formDataString = ""
        for (key, value) in formData {
            formDataString += "\(key)=\(value)&"
        }
        formDataString = String(formDataString.dropLast()) // Remove the trailing "&"
        
        // Set the request body
        request.httpBody = formDataString.data(using: .utf8)
        
        // Set the content type to "application/x-www-form-urlencoded"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        
        print("POST API call started at: \(startTime)")
        
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            
            let endTime = Date() // End time after receiving the API response
            
            
            let responseTime = endTime.timeIntervalSince(startTime) // Calculate the duration in seconds
            
            if let error = error {
                onCompletion(.failure(error))
                return
            }
            
            guard let data = data else {
                let error = NSError(domain: "No data received", code: 1, userInfo: nil)
                onCompletion(.failure(error))
                return
            }
            
            do {
                let decodedData = try JSONDecoder().decode(type, from: data)
                onCompletion(.success(decodedData))
                print(decodedData)
                
                print("POST API call ended at: \(endTime)")
                print("POST API response time: \(responseTime) seconds")
            } catch {
                onCompletion(.failure(error))
            }
        }
        
        task.resume()
    }
    
    func postAPIValuesScore<T: Codable>(
        type: T.Type,
        apiUrl: String,
        method: String,
        formData: [String: Int], // Dictionary for form data parameters
        onCompletion: @escaping (Result<T, Error>) -> Void
    ) {
        let startTime = Date() // Start time before making the API call
        
        guard let url = URL(string: apiUrl) else {
            let error = NSError(domain: "Invalid URL", code: 0, userInfo: nil)
            onCompletion(.failure(error))
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        // Construct the form data string
        var formDataString = ""
        for (key, value) in formData {
            formDataString += "\(key)=\(value)&"
        }
        formDataString = String(formDataString.dropLast()) // Remove the trailing "&"
        
        // Set the request body
        request.httpBody = formDataString.data(using: .utf8)
        
        // Set the content type to "application/x-www-form-urlencoded"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        
        print("POST API call started at: \(startTime)")
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            let endTime = Date() // End time after receiving the API response
            
            
            let responseTime = endTime.timeIntervalSince(startTime) // Calculate the duration in seconds
            
            
            
            if let error = error {
                onCompletion(.failure(error))
                return
            }
            
            guard let data = data else {
                let error = NSError(domain: "No data received", code: 1, userInfo: nil)
                onCompletion(.failure(error))
                return
            }
            
            do {
                let decodedData = try JSONDecoder().decode(type, from: data)
                onCompletion(.success(decodedData))
                print(decodedData)
                print("POST API call ended at: \(endTime)")
                print("POST API response time: \(responseTime) seconds")
                
            } catch {
                onCompletion(.failure(error))
            }
        }
        
        task.resume()
    }
        }
    
    func postAPIValuesCompiler<T: Codable>(
        type: T.Type,
        apiURL: String,
        method: String,
        username: String,
        code: String,
        input: String?,
        completion: @escaping (Result<T, Error>) -> Void
    ) {
        // Additional validation for required parameters
        guard !username.isEmpty else {
            let error = NSError(domain: "Invalid username", code: 0, userInfo: nil)
            completion(.failure(error))
            return
        }

        guard !code.isEmpty else {
            let error = NSError(domain: "Invalid code", code: 0, userInfo: nil)
            completion(.failure(error))
            return
        }

        // Optionally check for input data
        // Comment out or remove this block if input data is optional
        guard let inputData = input else {
            let error = NSError(domain: "Invalid input data", code: 0, userInfo: nil)
            completion(.failure(error))
            return
        }

        guard let url = URL(string: apiURL) else {
            let error = NSError(domain: "Invalid URL", code: 0, userInfo: nil)
            completion(.failure(error))
            return
        }

        // Encode the Java code
        let javaCode = """
        import java.util.Scanner;
        public class Odd {
            public static void main(String[] args) {
                Scanner reader = new Scanner(System.in);
                System.out.print("Enter a number: ");
                int num = reader.nextInt();
                if(num % 2 == 0)
                    System.out.println(num + " is even");
                else
                    System.out.println(num + " is odd");
            }
        }
        """

        if let encodedJavaCode = javaCode.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) {
            // Construct form data dictionary
            let formData: [String: Any] = [
                "username": username,
                "code": code,
                "input_data": input ?? 0
            ]

            // Convert form data dictionary to URL-encoded string
            let formDataString = formData.map { "\($0.key)=\($0.value)" }.joined(separator: "&")

            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.httpBody = formDataString.data(using: .utf8)

            request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

            URLSession.shared.dataTask(with: request) { (data, response, error) in
                if let error = error {
                    completion(.failure(error))
                    return
                }

                guard let data = data else {
                    let error = NSError(domain: "No data received", code: 1, userInfo: nil)
                    completion(.failure(error))
                    return
                }

                do {
                    let decoder = JSONDecoder()
                    let decodedData = try decoder.decode(T.self, from: data)
                    completion(.success(decodedData))
                } catch {
                    completion(.failure(error))
                }
            }.resume()
        }
    }

     


