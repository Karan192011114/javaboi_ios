//
//  File.swift
//  javaBoi
//
//  Created by SAIL on 03/11/23.
//

import Foundation

// MARK: - Welcome
struct Loginsession: Codable {
    var message: String?
    var data: [sessionData]?
}

// MARK: - Datum
struct sessionData: Codable {
    var username, password: String?
}

