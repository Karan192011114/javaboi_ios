//
//  ScoreExp2Model.swift
//  javaBoi
//
//  Created by SAIL on 30/10/23.
//

import Foundation

// MARK: - Welcome
struct ScoreExp2Model: Codable {
    var status: Bool?
    var message: String?
    var data: [ScoreExp2ModelData]?
}

// MARK: - Datum
struct ScoreExp2ModelData: Codable {
    var username, expLevel2: String?

    enum CodingKeys: String, CodingKey {
        case username
        case expLevel2 = "exp_level2"
    }
}
