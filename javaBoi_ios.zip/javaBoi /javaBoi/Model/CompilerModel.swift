//
//  CompilerModel.swift
//  javaBoi
//
//  Created by SAIL on 18/11/23.
//

import Foundation

// MARK: - Welcome
struct Compiler: Codable {
    var output: String?
//    var username: String
//    var code: String
//    var inputData: String

        enum CodingKeys: String, CodingKey {
            case output
//            , username, code
//            case inputData = "input_data"
        }
    
//    var categorizedOutput: String {
//        guard let output = output else {
//            return "No output available"
//        }
//
//        if output.lowercased().contains("error") {
//            return "Output contains error"
//        } else {
//            return "Output is normal"
//        }
//    }
}
    
