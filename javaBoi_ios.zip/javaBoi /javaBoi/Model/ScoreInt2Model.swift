//
//  ScoreInt2Model.swift
//  javaBoi
//
//  Created by SAIL on 30/10/23.
//

import Foundation

// MARK: - Welcome
struct ScoreInt2Model: Codable {
    var status: Bool?
    var message: String?
    var data: [ScoreInt2ModelData]?
}

// MARK: - Datum
struct ScoreInt2ModelData: Codable {
    var username, intLevel2: String?

    enum CodingKeys: String, CodingKey {
        case username
        case intLevel2 = "int_level2"
    }
}
