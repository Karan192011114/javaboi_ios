//
//  ScoreInt3Model.swift
//  javaBoi
//
//  Created by SAIL on 30/10/23.
//

import Foundation

// MARK: - Welcome
struct ScoreInt3Model: Codable {
    var status: Bool?
    var message: String?
    var data: [ScoreInt3ModelData]?
}

// MARK: - Datum
struct ScoreInt3ModelData: Codable {
    var username, intLevel3: String?

    enum CodingKeys: String, CodingKey {
        case username
        case intLevel3 = "int_level3"
    }
}
