//
//  ScoreExp3Model.swift
//  javaBoi
//
//  Created by SAIL on 30/10/23.
//

import Foundation

// MARK: - Welcome
struct ScoreExp3Model: Codable {
    var status: Bool?
    var message: String?
    var data: [ScoreExp3ModelData]?
}

// MARK: - Datum
struct ScoreExp3ModelData: Codable {
    var username, expLevel3: String?

    enum CodingKeys: String, CodingKey {
        case username
        case expLevel3 = "exp_level3"
    }
}
