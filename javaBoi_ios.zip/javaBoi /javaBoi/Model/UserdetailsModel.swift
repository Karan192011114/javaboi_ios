//
//  UserdetailsModel.swift
//  javaBoi
//
//  Created by SAIL on 16/11/23.
//

import Foundation

// MARK: - Welcome
struct userdetails: Codable {
    var userData: [UserDatum]?
    var status: String?
}

// MARK: - UserDatum
struct UserDatum: Codable {
    var username, email: String?
}
