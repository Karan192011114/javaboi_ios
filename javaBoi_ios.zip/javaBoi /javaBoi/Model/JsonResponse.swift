//
//  JsonResponse.swift
//  building management
//
//  Created by SAIL on 20/10/23.
//

import Foundation

// MARK: - Welcome
struct JsonResponseModel: Codable {
    let questions: [Question]?
}

// MARK: - Question
struct Question : Codable {
    let question: String?
    let answer: [Answer]?
    var value: Int?
    var correct: String?
}

// MARK: - Answer
struct Answer : Codable {
    let text: String?
    let correct: Bool?
}
