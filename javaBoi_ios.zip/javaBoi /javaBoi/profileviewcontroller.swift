//
//  profileviewcontroller.swift
//  javaBoi
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class profileviewcontroller: UIViewController {

    
    @IBOutlet weak var scoreboardbtn: UIImageView!
    
    @IBOutlet weak var homebtn: UIImageView!
    
    
    @IBOutlet weak var username: UILabel!
    
    @IBOutlet weak var email: UILabel!
    
    
    @IBOutlet weak var points: UILabel!
    
    
    
    var profileModel: Profile!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        scoreboardbtn.addAction(for: .tap){
            let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Scoreboardviewcontroller") as! Scoreboardviewcontroller
            self.navigationController?.pushViewController(signupVC, animated: true)
            
//            for controller in self.navigationController!.viewControllers as Array {
//                if controller.isKind(of: Scoreboardviewcontroller.self) {
//                    self.navigationController!.popToViewController(controller, animated: true)
//                    break
//                }
//            }
        }
        homebtn.addAction(for: .tap){
            let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "competencyviewcontroller") as! competencyviewcontroller
            self.navigationController?.pushViewController(signupVC, animated: true)
        }
        getProfileAPI()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
          func getProfileAPI() {
              APIHandler().getAPIValues(type: Profile.self, apiUrl: ServiceAPI.profileURL, method: "GET") { result in
                  switch result {
                  case .success(let data):
                      self.profileModel = data
                      print(self.profileModel.data ?? "")
                      print(self.profileModel.data?.count ?? 0)
                      DispatchQueue.main.async {
                          
                          self.username.text = self.profileModel.data?.first?.username
                          self.email.text = self.profileModel.data?.first?.email
                          self.points.text = self.profileModel.data?.first?.points
                          
                      }
                  case .failure(let error):
                      print(error)
                  }
              }
}
    @IBAction func badgebtn(_ sender: Any) {
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Achievementviewcontroller") as! Achievementviewcontroller
          self.navigationController?.pushViewController(nextVC, animated: true)
    }
}
