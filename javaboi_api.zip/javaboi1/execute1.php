<?php
// Enable error reporting for debugging purposes
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json'); // Set the content type to JSON

$response = array(); // Create an associative array for the response

$un = $_POST["username"];
$code = $_POST["code"];
$input = $_POST["input_data"];

// Initialize variables
$runtime_error = "";
$output = "";

if (empty($code)) {
    $response["error"] = "The code area is empty";
} else {
    $filename_code = "R" . $un . ".java";
    $filename_in = "input" . $un . ".txt";
    $filename_error = "error" . $un . ".txt";
    $runtime_file = "runtime" . $un . ".txt";
    $executable = "R" . $un . ".class";
    $out = "java R" . $un;

    $file_code = fopen($filename_code, "w+");
    fwrite($file_code, $code);
    fclose($file_code);

    if (!empty($input)) {
        $file_in = fopen($filename_in, "w+");
        fwrite($file_in, $input);
        fclose($file_in);
        $out .= " < " . $filename_in;
    }

    $command = "javac " . $filename_code;
    $command_error = $command . " 2>" . $filename_error;
    $runtime_error_command = $out . " 2>" . $runtime_file;

    exec($command_error);
    $error = file_get_contents($filename_error);

    $response["output"] = ""; // Initialize output in the response

    if (trim($error) == "") {
        exec($runtime_error_command);
        $runtime_error = file_get_contents($runtime_file);

        if (trim($runtime_error) == "") {
            $output = shell_exec($out);
            $response["output"] = $output;
        } else {
            $response["error"] = $runtime_error;
        }
    } else {
        $response["error"] = $error;
    }
}

// Remove debug information from the response
unset($response["debug"]);

echo json_encode($response);
?>
