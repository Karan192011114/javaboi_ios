<?php


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Receive the username and password from the POST request
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Store them in session variables
    $_SESSION['username'] = $username;
    $_SESSION['password'] = $password;

    // Prepare the data array to be sent in the response
    $userData = [
        'username' => $username,
        'password' => $password,
    ];

    // Send a response back to your iOS app with the data array
    $response = [
        'message' => 'Data saved in session',
        'data' => [$userData], // Wrap the user data in an array
    ];
    echo json_encode($response);
} else {
    // Handle other cases, such as GET requests
    // You can return an error response or perform other actions here
    $response = [
        'error' => 'Invalid request method',
    ];
    echo json_encode($response);
}
?>
