<?php
require_once('dbh.php');

// Initialize the response array
$response = [];

// Check if the request method is GET
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Fetch all users' usernames and emails
    $query = "SELECT username, email FROM user_info";
    $result = mysqli_query($conn, $query);

    $userData = [];

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            // Populate the user data array with username and email
            $userData[] = [
                'username' => $row['username'],
                'email' => $row['email'],
            ];
        }

        // Add the user data to the response
        $response['userData'] = $userData;
        $response['status'] = 'success';
    } else {
        // Handle the case when no users are found
        $response['status'] = 'error';
        $response['message'] = 'No users found.';
    }

    // Close the database connection
    mysqli_close($conn);
} else {
    // Handle the case when the request method is not GET
    $response['status'] = 'error';
    $response['message'] = 'Invalid request method.';
}

// Set the response content type to JSON
header('Content-Type: application/json');

// Output the JSON response
echo json_encode($response);
?>