<?php
require_once('dbh.php');
session_start();

$response = array(); // Initialize the response array

if (isset($_GET['username']) && isset($_GET['password'])) {
    $username = $_GET['username'];
    $provided_password = $_GET['password'];

    // Use prepared statement to avoid SQL injection
    $loginqry = "SELECT user_id, username, password FROM user_info WHERE username = ?";
    $stmt = mysqli_prepare($conn, $loginqry);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);

        if (mysqli_stmt_num_rows($stmt) > 0) {
            mysqli_stmt_bind_result($stmt, $user_id, $username, $stored_password);
            mysqli_stmt_fetch($stmt);

            // Verify password
            if ($provided_password === $stored_password) {
                // Password is correct, store user data in session
                $_SESSION['user_id'] = $user_id;
                $_SESSION['username'] = $username;

                $response['status'] = true;
                $response['message'] = "Login Successful";
                $response['data'] = array(array('user_id' => strval($user_id), 'username' => $username, 'password' => $stored_password ));
            } else {
                // Password is incorrect
                $response['status'] = false;
                $response['message'] = "Login Failed: Incorrect password";
            }
        } else {
            // No user found with the provided username
            $response['status'] = false;
            $response['message'] = "Login Failed: User not found";
        }

        mysqli_stmt_close($stmt);
    } else {
        // Error in prepared statement
        $response['status'] = false;
        $response['message'] = "Database query error: " . mysqli_error($conn);
    }
} else {
    // Invalid or missing username/password parameters
    $response['status'] = false;
    $response['message'] = "Invalid request parameters";
}

// Set the appropriate content type for JSON
header('Content-Type: application/json; charset=UTF-8');

// Output the JSON response
echo json_encode($response);
?>
